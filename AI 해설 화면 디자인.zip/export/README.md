# HL사이언스 AI 건강관리 해설지

GitHub Pages: https://saehwamomenti-wq.github.io/hl-ai-report/

## 구성
- `index.html` — 단일 파일 번들(오프라인 동작). 저장소 루트에 업로드.
- `src/AI-Interpretation-Screen.dc.html` — 화면 원본
- `src/support.js` — 런타임
- `src/ios-frame.jsx` — 디바이스 프레임

## PDF
`health-report.pdf`는 번들에 포함되지 않습니다. 저장소 루트에 함께 올려야 하단 "PDF 다운로드" 버튼이 파일명 지정 다운로드로 동작합니다.
