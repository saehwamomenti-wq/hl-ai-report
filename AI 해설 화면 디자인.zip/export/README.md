# AI 해설 화면 디자인

- `index.html` — 단일 파일 번들 (오프라인 동작, GitHub Pages 바로 배포 가능)
- `src/` — 편집용 원본 (`AI-Interpretation-Screen.dc.html` + `support.js`, 같은 폴더에 두고 열기)

배포 사이트: https://ai-cd-f001a2d8c5.netlify.app
